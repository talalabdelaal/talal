package standarddeviationcalculator;

import java.util.ArrayList;

public class distribution
{

    //initializes private variables
    private ArrayList<Double> distribution;
    private double numX;

    //saves private variables from the main class
    public distribution(double numX, ArrayList<Double> distribution)
    {
        this.numX = numX;
        this.distribution = distribution;

    }

    //calculates which distribution the number lies based on the arraylist and the user input numX
    public String getDistribution()
    {
        if (numX < distribution.get(0))
        {
            return "Your number lies farther than the 3rd standard deviation";
        }
        else if (numX > distribution.get(6))
        {
            return "Your number lies farther than the 3rd standard deviation";
        }
        else if (distribution.get(0) <= numX && distribution.get(1) >= numX)
        {
            return "Your number lies in the 3rd standard deviation";
        }
        else if (distribution.get(1) <= numX && distribution.get(2) >= numX)
        {
            return "Your number lies in the 2nd standard deviation";
        }
        else if (distribution.get(2) <= numX && distribution.get(3) > numX)
        {
            return "Your number lies in the 1st standard deviation";
        }
        else if (numX == distribution.get(3))
        {
            return "Your number is equal to the mean";
        }
        else if (distribution.get(3) < numX && distribution.get(4) >= numX)
        {
            return "Your number lies in the 1st standard deviation";
        }
        else if (distribution.get(4) <= numX && distribution.get(5) >= numX)
        {
            return "Your number lies in the 2nd standard deviation";
        }
        else if (distribution.get(5) < numX && distribution.get(6) >= numX)
        {
            return "Your number lies in the 3rd standard deviation";
        }
        else
        {
            return "";
        }
    }

    public String toString()
    {
        return getDistribution();
    }
}
