package standarddeviationcalculator;

public class zScoreCalc
{

    //initializes private variables
    private double numX;
    private double mean;
    private double sd;
    private double zScore;
    private final double HUNDRED = 100;

    //saves private variables from the main class
    public zScoreCalc(double numX, double mean, double sd)
    {
        this.numX = numX;
        this.mean = mean;
        this.sd = sd;

    }

    //calculates, rounds, and returns the z-score
    public double getZScore()
    {
        zScore = (numX - mean) / sd;

        zScore = zScore * HUNDRED;
        zScore = Math.round(zScore);
        zScore = zScore / HUNDRED;
        return zScore;
    }

    //prints z-score
    public String toString()
    {
        return "Your Z-Score is: " + getZScore();
    }

}
