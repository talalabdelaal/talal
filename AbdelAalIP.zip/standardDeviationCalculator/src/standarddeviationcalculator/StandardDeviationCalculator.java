/*
Talal Abdel Aal
12/1/20
This program takes a user given set of data and calculates the mean,
standard deviation, 3 distributions, and the z-score using their appropriate
equations.
 */
 /*
pseudocode:
4 classes
to calculate mean, standard deviation, distribution, and zscore
main class has to prompt user and enter our set of data
standard deviation class has to use mean and subtract all variable by the mean
mean must be a public variable in main or in class
must figure out how to transfer arraylists between classes
inheritance? (super class?)
z=(x-m)/s
review classes and inheritance

 */
package standarddeviationcalculator;

import java.util.*;

public class StandardDeviationCalculator
{

    public static void main(String[] args)
    {
        //initialized variables
        double[] data = new double[100];
        ArrayList<Double> distribution = new ArrayList<Double>();
        Scanner input = new Scanner(System.in);
        int noOfVar;
        double sum;
        double mean;
        double numX;
        double sd;
        String answer;

        do
        {
            //prompt user
            System.out.println("How many numbers are we using to find the mean?");
            noOfVar = input.nextInt();
            System.out.println("Please enter your set of data below:");
            //clears for multiple runs
            distribution.clear();
            sum = 0;
            //adds numbers that the user inputs and add the numbers to arraylist
            for (int i = 0; i < noOfVar; i++)
            {
                data[i] = input.nextDouble();
            }
            for (int i = 0; i < noOfVar; i++)
            {
                sum += data[i];
            }
            //calls the mean class and uses data, the number of variables, and the sum to calculate the mean
            mean mTester = new mean(noOfVar, sum);
            System.out.println(mTester);

            //sets our main class mean variable to the mean in the mean class (implemented in line 65)
            mean = mTester.getMean();

            //calls the standard deviation class to find sd
            standardDeviation sdTester = new standardDeviation(data, noOfVar, mean);
            System.out.println(sdTester);

            //initailizes our new arraylist and stores the variables in the getDistribution method
            sdTester.getDistribution();

            //prints the arraylist according to the original order
            System.out.println("Or: " + sdTester.distribution + " with the mean in the center and each deviation away from the mean");

            //prompts user for X
            System.out.println("Which number do you want to calculate the z-score and determine in which standard distribution it lies?");
            numX = input.nextDouble();

            //calculates and prints distribution using the new user input
            distribution distTester = new distribution(numX, sdTester.distribution);
            System.out.println(distTester);

            //sets our sd variable in our main to store the return in the getStandardDeviation method
            sd = sdTester.getStandardDeviation();

            //calculates and prints the z-score
            zScoreCalc zTester = new zScoreCalc(numX, mean, sd);
            System.out.println(zTester);

            //repeats until user doesnt say yes
            System.out.println("Would you like to repeat? (Y/N)");
            answer = input.next();

            //loops the entire program
        } while (answer.charAt(0) == ('y') || answer.charAt(0) == ('Y'));
    }
}
