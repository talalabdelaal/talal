package standarddeviationcalculator;

import java.util.*;

public class standardDeviation
{

    //initializes private variables except distribution because it is intially used to store variables in this class rather than the main class
    private double mean;
    private double newSum = 0;
    private double var;
    private double sd;
    private double temp;
    private double[] data;
    public ArrayList<Double> distribution = new ArrayList<Double>();
    private final int noOfVar;
    private final int HUNDRED = 100;
    private double SD1pos;
    private double SD1neg;
    private double SD2pos;
    private double SD2neg;
    private double SD3pos;
    private double SD3neg;

    //saves private variables from the main class
    public standardDeviation(double[] data, int noOfVar, double mean)
    {
        this.data = data;
        this.noOfVar = noOfVar;
        this.mean = mean;
    }

    //calculates variation and rounds it
    public double getVariation()
    {

        for (int i = 0; i < noOfVar; i++)
        {
            temp = data[i] - mean;
            newSum += temp * temp;
        }
        var = newSum / noOfVar;

        var = var * HUNDRED;
        var = Math.round(var);
        var = var / HUNDRED;

        return var;
    }

    //calculates the standard deviation and rounds it
    public double getStandardDeviation()
    {
        sd = Math.sqrt(var);

        sd = sd * HUNDRED;
        sd = Math.round(sd);
        sd = sd / HUNDRED;

        return sd;
    }

    //the rest are used to calculate the distribution and rounds them
    public double getSD1pos()
    {
        SD1pos = sd + mean;

        SD1pos = SD1pos * HUNDRED;
        SD1pos = Math.round(SD1pos);
        SD1pos = SD1pos / HUNDRED;

        return SD1pos;
    }

    public double getSD1neg()
    {
        SD1neg = mean - sd;

        SD1neg = SD1neg * HUNDRED;
        SD1neg = Math.round(SD1neg);
        SD1neg = SD1neg / HUNDRED;

        return SD1neg;
    }

    public double getSD2pos()
    {
        SD2pos = SD1pos + sd;

        SD2pos = SD2pos * HUNDRED;
        SD2pos = Math.round(SD2pos);
        SD2pos = SD2pos / HUNDRED;

        return SD2pos;
    }

    public double getSD2neg()
    {
        SD2neg = SD1neg - sd;

        SD2neg = SD2neg * HUNDRED;
        SD2neg = Math.round(SD2neg);
        SD2neg = SD2neg / HUNDRED;

        return SD2neg;
    }

    public double getSD3pos()
    {
        SD3pos = SD2pos + sd;

        SD3pos = SD3pos * HUNDRED;
        SD3pos = Math.round(SD3pos);
        SD3pos = SD3pos / HUNDRED;

        return SD3pos;
    }

    public double getSD3neg()
    {
        SD3neg = SD2neg - sd;

        SD3neg = SD3neg * HUNDRED;
        SD3neg = Math.round(SD3neg);
        SD3neg = SD3neg / HUNDRED;

        return SD3neg;
    }

    //this method adds all of the distributions to the arraylist distribution but is initialized in the main class (see main class for more)
    public void getDistribution()
    {
        distribution.add(this.getSD3neg());
        distribution.add(this.getSD2neg());
        distribution.add(this.getSD1neg());
        distribution.add(this.mean);
        distribution.add(this.getSD1pos());
        distribution.add(this.getSD2pos());
        distribution.add(this.getSD3pos());

    }

    //prints the variation and the distributions
    public String toString()
    {

        return "The variation is: " + getVariation() + ("\nand the standard deviation is: ") + getStandardDeviation() + " \nTherefore the first, second, and third standard deviations are: ("
            + getSD1neg() + "," + getSD1pos() + ")" + "(" + getSD2neg() + "," + getSD2pos() + ")" + "(" + getSD3neg() + "," + getSD3pos() + "), respectively.";

    }
}
