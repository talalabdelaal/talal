package standarddeviationcalculator;

import java.util.*;

public class mean
{

    //initializes private variables but data remains public to be used in the sd class
    private int noMean;
    private double sum;
    private double mean;
    private final int HUNDRED = 100;

    //saves private variables from the main class
    public mean(int noMean, double sum)
    {
        this.noMean = noMean;
        this.sum = sum;

    }

    //calculates and returns the mean
    double getMean()
    {
        mean = sum / noMean;

        mean = mean * HUNDRED;
        mean = Math.round(mean);
        mean = mean / HUNDRED;

        return mean;
    }

    //prints the mean
    public String toString()
    {
        return "Your mean is: " + getMean();
    }
}
